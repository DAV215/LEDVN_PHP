<link rel="stylesheet" href="asset/css/Banner_css/banner.css">
<div class="content" id="banner">
    Banner 
</div>