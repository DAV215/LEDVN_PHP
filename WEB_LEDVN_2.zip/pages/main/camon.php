<div class="content">
    <div class="thanks">
    <img src="https://fckadqd.stripocdn.email/content/guids/CABINET_c0e87147643dfd412738cb6184109942/images/151618429860259.png" alt="" style="display: block;" width="200px">
        <h1>Cảm ơn bạn đã đặt hàng, nhân viên LEDVN sẽ liên hệ sớm nhất.</h1>
        <h2>Đơn hàng của bạn đang được xử lý</h2>
        <h2>Có xác nhận đơn hàng gửi về mail của bạn, mong bạn xem qua.</h2>
    </div>
</div>