<link rel="stylesheet" href="asset/css/Menu_css/search_modal.css">
<script src="asset/js/search_live.js"></script>

<div class="search_modal">
    <div class="search_item_wrapper">
        <a href="#" class="child_search">
            <div class="child_content">
                <span class="item_name">Tên sản phẩm</span>
                <span>Kích thước: </span>
            </div>
            <div class="child_img">
                <img src="asset\images\banner_header\banner1.png" alt="">
            </div>
        </a>
    </div>
    <form action=""></form>
    <div class="more_search">
        <button>1</button>
    </div>
</div>