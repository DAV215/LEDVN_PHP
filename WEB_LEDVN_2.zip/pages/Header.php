
<link rel="stylesheet" href="asset/css/Header_css/Header.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="asset/js/header_banner.js"></script>
<div class="header_container">
  <div class="header">
      <div class="mark_header"></div>
      <div class="main_hd">
      <ul class="header_item_content">
        <li class="content_text">
          <h1 class="title">LEDVN</h1>
          <h2 class="content">Dịch vụ tận tâm - Giá trị xứng tầm</h2>
        </li>
      </ul>
      </div>
  </div>
</div>
<div class="mark_btn">
    <button id="prev_hd_banner" class="control_hd_banner" onclick="prev_hd_banner()"><i class="fa-solid fa-circle-chevron-left"></i></button>
    <button id="next_hd_banner" class="control_hd_banner" onclick="next_hd_banner()"><i class="fa-solid fa-circle-chevron-right"></i></button>
  </div>


