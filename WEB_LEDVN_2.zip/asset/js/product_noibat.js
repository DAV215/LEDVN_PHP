// let active = 0;
// let item = document.querySelectorAll('.item_product_noibat');
// let page_btn = document.querySelectorAll('#product_pagination_btn');
// item[active].classList.add('active');

// for (let i = 0; i < page_btn.length; i++) {
//     page_btn[i].addEventListener('click', function() {
//         active = i;
//         for (let j = 0; j < item.length; j++) {
//             page_btn[j].classList.remove('active');
//             item[j].classList.remove('active');
//         }
//         item[active].classList.add('active');
//         page_btn[active].classList.add('active');
//     })
// }

function casourel_slide(classA, ID_BTN_PAGINATION) {
    let active = 0;
    let item = document.querySelectorAll(classA);
    let page_btn = document.querySelectorAll(ID_BTN_PAGINATION);
    item[active].classList.add('active');

    for (let i = 0; i < page_btn.length; i++) {
        page_btn[i].addEventListener('click', function() {
            active = i;
            for (let j = 0; j < item.length; j++) {
                page_btn[j].classList.remove('active');
                item[j].classList.remove('active');
            }
            item[active].classList.add('active');
            page_btn[active].classList.add('active');
        })
    }
}
casourel_slide('#item_product_noibat', '#product_pagination_btn');
casourel_slide('#item_baiviet_noibat', '#baiviet_pagination_btn');