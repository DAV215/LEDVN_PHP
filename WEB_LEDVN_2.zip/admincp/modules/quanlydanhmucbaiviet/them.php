Thêm danh mục bài viết
<div class="wrapper">
    <form action="modules/quanlydanhmucbaiviet/xuly.php" method="post">
        <table class="data_table">
            <tr>
                <td>Tên danh mục</td>
                <td><input type="text" name="tendanhmuc" ></td>
            </tr>
            <tr>
                <td>Thứ tự</td>
                <td><input type="text" name="thutu" ></td>
            </tr>
                <tr>
                <td colspan="2"><input class="submit_btn" type="submit" name="themdanhmuc" value="Xác nhận thêm danh mục"></td>
            </tr>
        </table>

    </form>

</div>
